import os.path
import random
import torchvision.transforms as transforms
import torch
from data.base_dataset import BaseDataset
from data.image_folder import make_dataset
from PIL import Image


class AlignedDataset(BaseDataset):
    def __init__(self, opt):
        self.opt = opt
        self.root = opt.dataroot

        # ========== 高斯去噪：直接加载清晰图 ==========
        # 清晰图放在 dataroot/train/ 或 dataroot/val/ 下
        self.dir_clean = os.path.join(opt.dataroot, opt.phase)
        self.clean_paths = sorted(make_dataset(self.dir_clean))

        # 高斯去噪用全部数据（不采样2000张），因为在线加噪已经提供了无限多样性
        # 如果显式设置了 max_dataset_size 且不是inf，才截断（一般不设）
        max_size = getattr(opt, 'max_dataset_size', float('inf'))
        if max_size != float('inf') and len(self.clean_paths) > int(max_size):
            self.clean_paths = self.clean_paths[:int(max_size)]
            print(f"[Dataset] Limited to {len(self.clean_paths)} images by max_dataset_size")
        else:
            print(f"[Dataset] Using all {len(self.clean_paths)} clean images")

        # 预处理：ToTensor -> Normalize 到 [-1, 1]
        transform_list = [
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ]
        self.transform = transforms.Compose(transform_list)

        # 盲去噪噪声范围 [0, 50]
        self.sigma_range = (0, 50)

    def resample(self):
        """高斯去噪不需要每轮重新采样路径（噪声是在线随机的），留空即可"""
        pass

    def __getitem__(self, index):
        # 加载清晰图 B (Ground Truth)
        B_path = self.clean_paths[index]
        B_img = Image.open(B_path).convert('RGB')

        # Resize 到目标尺寸（如 256x256 或 512x512）
        B_img = B_img.resize((self.opt.loadSizeX, self.opt.loadSizeY), Image.BICUBIC)

        # 转为 Tensor [-1, 1]
        B = self.transform(B_img)

        # 随机裁剪 fineSize（数据增强，如从 256 裁剪到 128）
        if self.opt.fineSize < self.opt.loadSizeX or self.opt.fineSize < self.opt.loadSizeY:
            h, w = B.size(1), B.size(2)
            h_offset = random.randint(0, max(0, h - self.opt.fineSize - 1))
            w_offset = random.randint(0, max(0, w - self.opt.fineSize - 1))
            B = B[:, h_offset:h_offset + self.opt.fineSize,
                w_offset:w_offset + self.opt.fineSize]

        # 水平翻转（数据增强）
        if (not self.opt.no_flip) and random.random() < 0.5:
            B = torch.flip(B, [2])

        # ========== 核心：在线生成高斯噪声（每次都不一样） ==========
        # 随机选择噪声水平 σ ∈ [0, 50]
        sigma = random.uniform(self.sigma_range[0], self.sigma_range[1])

        # 像素域 sigma 映射到归一化空间 [-1, 1]
        # 原图 [0,255] -> sigma/255；归一化后 [-1,1] 范围扩大2倍 -> 乘以2
        noise_std = sigma / 255.0 * 2
        noise = torch.randn_like(B) * noise_std
        A = B + noise

        # 裁剪到 [-1, 1] 范围（防止越界）
        A = torch.clamp(A, -1, 1)

        return {
            'A': A,  # 噪声图（输入）
            'B': B,  # 清晰图（Ground Truth）
            'A_paths': B_path,  # 路径信息
            'B_paths': B_path,
            'sigma': sigma  # 当前噪声水平（可用于日志/debug）
        }

    def __len__(self):
        # 返回全部清晰图数量（不限制2000张）
        return len(self.clean_paths)

    def name(self):
        return 'AlignedDataset'