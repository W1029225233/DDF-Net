import torch.utils.data
from data.base_data_loader import BaseDataLoader

# 这个函数负责根据传入的 opt（通常是一个配置对象，包含数据集和训练选项的设置）创建相应的数据集对象
def CreateDataset(opt):
    dataset = None
    # 'aligned'：创建 AlignedDataset，可能用于成对的图像数据，如图像翻译任务中的成对训练图像。
    if opt.dataset_mode == 'aligned':
        from data.aligned_dataset import AlignedDataset
        dataset = AlignedDataset(opt)
    # 'unaligned'：创建 UnalignedDataset，可能用于不成对的图像数据，如风格迁移任务。
    elif opt.dataset_mode == 'unaligned':
        from data.unaligned_dataset import UnalignedDataset
        dataset = UnalignedDataset()
    # 'single'：创建 SingleDataset，可能用于单一图像的数据集，如图像超分辨率。
    elif opt.dataset_mode == 'single':
        from data.single_dataset import SingleDataset
        dataset = SingleDataset()
        dataset.initialize(opt)
    else:
        raise ValueError("Dataset [%s] not recognized." % opt.dataset_mode)

    print("dataset [%s] was created" % (dataset.name()))
    # dataset.initialize(opt)
    return dataset

# 继承自 BaseDataLoader，这是一个自定义的类，用于管理数据加载过程。
class CustomDatasetDataLoader(BaseDataLoader):
    # name(self) 方法：返回数据加载器的名称，这里是 'CustomDatasetDataLoader'。
    def name(self):
        return 'CustomDatasetDataLoader'
    # 构造函数 __init__(self, opt)：
    def __init__(self, opt):
        # 首先调用基类的 initialize 方法，这可能用于设置一些基本的配置。
        super(CustomDatasetDataLoader,self).initialize(opt)
        # 打印出 opt.nThreads 的值，这是一个配置参数，表示数据加载时使用的线程数。
        print("Opt.nThreads = ", opt.nThreads)
        # 调用 CreateDataset 函数来创建数据集对象，并将其赋值给 self.dataset。
        self.dataset = CreateDataset(opt)
        # 使用 PyTorch 的 torch.utils.data.DataLoader 创建一个数据加载器：
        self.dataloader = torch.utils.data.DataLoader(
            # self.dataset：数据集对象，它将被 DataLoader 用来加载数据。
            self.dataset,
            # batch_size=opt.batchSize：每个批次的样本数。
            batch_size=opt.batchSize,
            # shuffle=not opt.serial_batches：是否在每个epoch开始时打乱数据。如果 opt.serial_batches 为 True，则不打乱。
            shuffle=not opt.serial_batches,
            # num_workers=int(opt.nThreads)：加载数据时使用的子进程数。
            num_workers=int(opt.nThreads)
        )

    def load_data(self):
        return self.dataloader

    def __len__(self):
        return min(len(self.dataset), self.opt.max_dataset_size)
