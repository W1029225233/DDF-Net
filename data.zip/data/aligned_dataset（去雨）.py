import os.path
import random
import torchvision.transforms as transforms
import torch
from data.base_dataset import BaseDataset
from data.image_folder import make_dataset
from PIL import Image


class AlignedDataset(BaseDataset):
    def __init__(self, opt):
        self.opt = opt
        self.root = opt.dataroot
        self.dir_AB = os.path.join(opt.dataroot, opt.phase)

        # 关键修改1：保存所有路径（全集）
        self.all_paths = sorted(make_dataset(self.dir_AB))

        # 关键修改2：设置每轮采样的数量（默认2000，可通过opt.max_dataset_size设置）
        self.samples_per_epoch = getattr(opt, 'max_dataset_size', 2000)

        # 关键修改3：初始采样一次
        self.current_paths = []
        self.resample()

        transform_list = [
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5),
                                 (0.5, 0.5, 0.5))]
        self.transform = transforms.Compose(transform_list)

    def resample(self):
        """
        关键方法：每个epoch重新随机采样2000张
        """
        if len(self.all_paths) > self.samples_per_epoch:
            # 从全集中随机选2000张
            self.current_paths = random.sample(self.all_paths, self.samples_per_epoch)
        else:
            # 如果总数不足2000，用全部
            self.current_paths = self.all_paths.copy()

        # 打乱顺序（增加随机性）
        random.shuffle(self.current_paths)
        print(f"[Dataset] Resampled: {len(self.current_paths)} images (from {len(self.all_paths)} total)")

    def __getitem__(self, index):
        # 关键修改4：从current_paths取图，而不是all_paths
        AB_path = self.current_paths[index]
        AB = Image.open(AB_path).convert('RGB')
        # Resize to twice the width for two images
        AB = AB.resize((self.opt.loadSizeX * 2, self.opt.loadSizeY), Image.BICUBIC)
        AB = self.transform(AB)

        w_total = AB.size(2)
        w = int(w_total / 2)
        h = AB.size(1)
        w_offset = random.randint(0, max(0, w - self.opt.fineSize - 1))
        h_offset = random.randint(0, max(0, h - self.opt.fineSize - 1))

        A = AB[:, h_offset:h_offset + self.opt.fineSize,
            w_offset:w_offset + self.opt.fineSize]
        B = AB[:, h_offset:h_offset + self.opt.fineSize,
            w + w_offset:w + w_offset + self.opt.fineSize]

        if (not self.opt.no_flip) and random.random() < 0.5:
            idx = [i for i in range(A.size(2) - 1, -1, -1)]
            idx = torch.LongTensor(idx)
            A = A.index_select(2, idx)
            B = B.index_select(2, idx)

        return {'A': A, 'B': B,
                'A_paths': AB_path, 'B_paths': AB_path}

    def __len__(self):
        # 关键修改5：返回采样后的长度（2000），不是全集长度
        return len(self.current_paths)

    def name(self):
        return 'AlignedDataset'