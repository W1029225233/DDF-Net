import torch
import torch.nn as nn
# from torch.nn import init
import functools
# from torch.autograd import Variable
import numpy as np
import torchvision.models as models
import torch.nn.functional as F
from net_canny import Net
import torch.fft
from einops import rearrange
import numbers
import math
from mamba_ssm import Mamba
###############################################################################
# Functions
###############################################################################
def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        m.weight.data.normal_(0.0, 0.02)
        if hasattr(m.bias, 'data'):
            m.bias.data.fill_(0)
    elif classname.find('BatchNorm2d') != -1:
        m.weight.data.normal_(1.0, 0.02)
        m.bias.data.fill_(0)


def get_norm_layer(norm_type='instance'):
    if norm_type == 'batch':
        norm_layer = functools.partial(nn.BatchNorm2d, affine=True)
    elif norm_type == 'instance':
        norm_layer = functools.partial(nn.InstanceNorm2d, affine=False, track_running_stats=True)
    else:
        raise NotImplementedError('normalization layer [%s] is not found' % norm_type)
    return norm_layer


def define_G(input_nc, output_nc, ngf, which_model_netG, norm='instance', use_dropout=False, gpu_ids=[], use_parallel=True,
             learn_residual=False):
    netG = None
    use_gpu = len(gpu_ids) > 0
    norm_layer = get_norm_layer(norm_type=norm)

    if use_gpu:
        assert (torch.cuda.is_available())

    if which_model_netG == 'resnet_9blocks':
        netG = ResnetGenerator(input_nc, output_nc, ngf, norm_layer=norm_layer,  n_blocks=3, gpu_ids=gpu_ids, use_parallel=use_parallel, learn_residual=learn_residual)
    elif which_model_netG == 'resnet_6blocks':
        netG = ResnetGenerator_gs(norm_layer=norm_layer, use_dropout=use_dropout, n_blocks=3)                               # gpu_ids=gpu_ids, use_parallel=use_parallel, learn_residual=learn_residual)
    else:
        raise NotImplementedError('Generator model name [%s] is not recognized' % which_model_netG)
    if len(gpu_ids) > 0:
         netG.cuda(device=gpu_ids[0])
    netG.apply(weights_init)
    return netG


def define_D(input_nc, ndf, which_model_netD, n_layers_D=3, norm='batch', use_sigmoid=False, gpu_ids=[],
             use_parallel=True):
    netD = None
    use_gpu = len(gpu_ids) > 0
    norm_layer = get_norm_layer(norm_type=norm)

    if use_gpu:
        assert (torch.cuda.is_available())
    if which_model_netD == 'basic':
        netD = NLayerDiscriminator(input_nc, ndf, n_layers=3, norm_layer=norm_layer, use_sigmoid=use_sigmoid,
                                   gpu_ids=gpu_ids, use_parallel=use_parallel)

    elif which_model_netD == 'n_layers':
        netD  = UnetGenerator1(input_nc,  ndf, norm_layer=norm_layer, use_sigmoid=False,
                               gpu_ids=gpu_ids, use_parallel=use_parallel)
    else:
        raise NotImplementedError('Discriminator model name [%s] is not recognized' % which_model_netD)
    if use_gpu:
        netD.cuda(gpu_ids[0])
    netD.apply(weights_init)
    return netD


def print_network(net):
    num_params = 0
    for param in net.parameters():
        num_params += param.numel()
    print(net)
    print('Total number of parameters: %d' % num_params)


##############################################################################
# Classes
##############################################################################


# Defines the generator that consists of Resnet blocks between a few
# downsampling/upsampling operations.
# Code and idea originally from Justin Johnson's architecture.
# https://github.com/jcjohnson/fast-neural-style/
class ResnetGenerator_gs(nn.Module):
    def __init__(
        self, norm_layer=nn.InstanceNorm2d, use_dropout=False,
        n_blocks=6):
        super(ResnetGenerator_gs, self).__init__()
        self.netGi = models.vgg19_bn(pretrained=True)
        self.netGi = self.netGi.features[14]
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d
        self.netGi=torch.nn.Sequential(*list(self.netGi.children())[:])

    def forward(self, x):
        batchsize = x.size(0)
        x1 = self.netGi(x)
        return x1   



class DFFN(nn.Module):
    def __init__(self, dim, bias, ffn_expansion_factor):
        super(DFFN, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.patch_size = 8

        self.dim = dim
        # 卷积（输入通道，输出通道，卷积核，使用偏执）
        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)
        # 深度可分离卷积（Depthwise Separable Convolution）（输入通道，输出通道，卷积核，步长，填充，分离卷积，偏执）
        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3, stride=1, padding=1,
                                groups=hidden_features * 2, bias=bias)
        # 增加一个逐点卷积，增加表达能力
        self.pwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=1, bias=bias)
        # self.fft = nn.Parameter(torch.ones((hidden_features * 2, 1, 1, self.patch_size, self.patch_size // 2 + 1)))
        self.fft = nn.Parameter(torch.randn((hidden_features * 2, 1, 1, self.patch_size, self.patch_size // 2 + 1)))
        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

        # 它使用DFT（离散傅里叶变换）和IDFT（逆离散傅里叶变换）处理图像的频域表示
    def forward(self, x):
        # print("Input shape:", x.shape)  # 打印输入张量的形状

        # 一个卷积层（输入通道，输出通道为hidden_features的2倍，卷积核大小1），单纯变通道数
        x = self.project_in(x)  # ？？？？这里需要知道具体的维度变换数字
        h, w = x.shape[-2:]
        pad_h = (self.patch_size - h % self.patch_size) % self.patch_size
        pad_w = (self.patch_size - w % self.patch_size) % self.patch_size
        x = F.pad(x, (0, pad_w, 0, pad_h), mode='reflect')
        # Pad the input tensorx_patch = rearrange(x, 'b c (h patch1) (w patch2) -> b c h w patch1 patch2', patch1=self.patch_size,
        x_patch = rearrange(x, 'b c (h patch1) (w patch2) -> b c h w patch1 patch2', patch1=self.patch_size,
                            patch2=self.patch_size)
        # 频域转换：应用二维快速傅里叶变换
        x_patch_fft = torch.fft.rfft2(x_patch.float())
        # 乘了一个傅里叶变换核，逐元素乘法（详细了解一下），可以在频域中对图像进行滤波处理
        x_patch_fft = x_patch_fft * self.fft
        # 傅里叶反变换，变回时域
        x_patch = torch.fft.irfft2(x_patch_fft, s=(self.patch_size, self.patch_size))
        # print("Rearranged shape:", x_patch.shape)  # 打印重新排列后的张量形状
        # 重新排列
        x = rearrange(x_patch, 'b c h w patch1 patch2 -> b c (h patch1) (w patch2)', patch1=self.patch_size,
                      patch2=self.patch_size)
        # print("Rearranged shape2:", x_patch.shape)  # 打印重新排列后的张量形状
        # 去掉填充的部分
        x = x[:, :, :h, :w]
        # dim指定为 1，沿着通道维度进行分割
        x1, x2 = self.pwconv(self.dwconv(x)).chunk(2, dim=1)
        # 激活函数，逐元素惩罚
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x


class GroupDenseBlock(nn.Module):          # 轻量版 RDB-5C
    def __init__(self, nf=512, gc=256, groups=4, bias=True):
        super().__init__()
        self.nf, self.gc = nf, gc
        # 1×1 先降维，减少 3×3 分组卷积输入
        self.compress = nn.Conv2d(nf, gc//groups, 1, bias=bias)
        # 5 个 3×3 分组卷积，输入通道=gc//groups
        self.convs = nn.ModuleList([
            nn.Conv2d(gc//groups, gc//groups, 3, 1, 1,
                     groups=groups, bias=bias) for _ in range(5)
        ])
        # 1×1 升回 nf，做残差
        self.expand = nn.Conv2d(gc//groups, nf, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        y = self.compress(x)  # 64 ch
        for conv in self.convs:
            y = self.lrelu(conv(y))  # 仍然是 64 ch
        # 不再 cat，直接 1×1 升回 512
        out = self.expand(y)  # 512 ch
        return out * 0.2 + x

class RRDB(nn.Module):
    '''Residual in Residual Dense Block'''

    def __init__(self, nf=512, gc=256):
        super(RRDB, self).__init__()
        self.RDB1 = GroupDenseBlock(nf, gc)
        self.RDB2 = GroupDenseBlock(nf, gc)
        self.RDB3 = GroupDenseBlock(nf, gc)

    def forward(self, x):
        out = self.RDB1(x)
        out = self.RDB2(out)
        out = self.RDB3(out)
        return out * 0.2 + x

class Block(nn.Module):
    def __init__(self, input_channel=64, output_channel=64, kernel_size=3, stride=1, padding=1):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(input_channel, output_channel, kernel_size, stride, bias=False, padding=1),
            nn.BatchNorm2d(output_channel),
            nn.PReLU(),

            nn.Conv2d(output_channel, output_channel, kernel_size, stride, bias=False, padding=1),
            nn.BatchNorm2d(output_channel)
        )

    def forward(self, x0):
        x1 = self.layer(x0)
        return x0 + x1


class DualPathBlock(nn.Module):
    def __init__(self):
        super().__init__()

        # 自适应权重学习
        self.gate = nn.Parameter(torch.tensor([0.3]))  # 初始偏重空间域分支

    def forward(self, x1,x2):
        conv_path = x1
        fft_path = x2

        # 动态融合（sigmoid束在[0.1,0.9]范围）
        alpha = torch.sigmoid(self.gate) * 0.8 + 0.1
        return  alpha * fft_path + (1 - alpha) * conv_path

class StripeAttn(nn.Module):
    def __init__(self, dim, stripe='h', heads=4):
        super().__init__()
        self.stripe = stripe
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
    def forward(self, x):
        b,c,h,w = x.shape
        if self.stripe=='h':
            x = rearrange(x,'b c h w -> (b w) h c')
            out,_ = self.attn(x,x,x)
            out = rearrange(out,'(b w) h c -> b c h w',w=w)
        else:  # 'w'
            x = rearrange(x,'b c h w -> (b h) w c')
            out,_ = self.attn(x,x,x)
            out = rearrange(out,'(b h) w c -> b c h w',h=h)
        return out

class ResnetGenerator(nn.Module):
    def __init__(self, input_nc, output_nc, ngf=64, norm_layer=nn.InstanceNorm2d, n_blocks=2, gpu_ids=[], use_parallel=True, learn_residual=False):
        assert (n_blocks >= 0)
        super(ResnetGenerator, self).__init__()
        self.input_nc = input_nc
        self.output_nc = output_nc
        self.ngf = ngf
        self.gpu_ids = gpu_ids
        self.use_parallel = use_parallel
        self.learn_residual = learn_residual

        self.residual_block1 = nn.Sequential(*[Block(64, 64, 3, 1) for _ in range(5)])
        self.residual_block2 = nn.Sequential(*[Block(128, 128, 3, 1) for _ in range(5)])
        self.residual_block3 = nn.Sequential(*[Block(256, 256, 3, 1) for _ in range(5)])
        self.rd = nn.Sequential(*[RRDB(512, 256) for _ in range(2)])
        self.DP = DualPathBlock()
        # 构造函数中
        self.sa_h = StripeAttn(512, stripe='h', heads=8)  # 512 通道
        self.sa_w = StripeAttn(512, stripe='w', heads=8)
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d

        # 分支1：原始DFFN路径（保留频域处理能力）
        self.branch_fft1 = nn.Sequential(
            DFFN(64, bias=True, ffn_expansion_factor=1.5),
            nn.InstanceNorm2d(64)
        )
        self.branch_fft2 = nn.Sequential(
            DFFN(128, bias=True, ffn_expansion_factor=1.5),
            nn.InstanceNorm2d(128)
        )
        self.branch_fft3 = nn.Sequential(
            DFFN(256, bias=True, ffn_expansion_factor=1.5),
            nn.InstanceNorm2d(256)
        )

        # 分支2：增强卷积路径（新增）
        self.branch_conv0 = nn.Sequential(
            nn.ReflectionPad2d(3),
            nn.Conv2d(input_nc, ngf, kernel_size=7, padding=0, bias=use_bias),  # (4,3,256,256)-->(4,64,256,256)
            norm_layer(ngf),
            nn.GELU()
        )

        self.branch_conv1 = nn.Sequential(
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1, bias=use_bias),
            # (4,64,256,256)-->(4,64,256,256) 跟加block1
            norm_layer(64),
            nn.GELU()
        )

        self.branch_conv2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1, bias=use_bias),
            # (4,64,256,256)-->(4,128,128,128) 跟加block3
            norm_layer(128),
            nn.GELU()
        )

        self.branch_conv3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1, bias=use_bias),
            # (4,128,128,128)-->(4,256,64,64) 跟加block4
            norm_layer(256),
            nn.GELU()
        )
        self.branch_conv4 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, stride=2, padding=1, bias=use_bias),  # (4,256,64,64)-->(4,512,32,32) 跟加
            norm_layer(512),
            nn.GELU()
        )

        self.up_conv6 = nn.Sequential(
            nn.Conv2d(512, 1024, kernel_size=3, stride=1, padding=1, bias=use_bias),
            nn.PixelShuffle(2),  # (4,256,64,64)-->(4,128,128,128)
            norm_layer(256),
            nn.GELU()
        )

        self.up_conv7 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, stride=1, padding=1, bias=use_bias),
            nn.PixelShuffle(2),  # (4,256,64,64)-->(4,128,128,128)
            norm_layer(128),
            nn.GELU()
        )

        self.up_conv8 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1, bias=use_bias),
            nn.PixelShuffle(2),  # (4,256,64,64)-->(4,128,128,128)
            norm_layer(64),
            nn.GELU()
        )

        self.up_conv9 = nn.Sequential(
            nn.Conv2d(64, 3, kernel_size=3, padding=1, bias=use_bias),
            nn.Tanh()
        )

        # 应用权重初始化
        self.apply(weights_init)  # 在这里调用权重初始化函数

    def forward(self, input):
        if self.gpu_ids and isinstance(input.data, torch.cuda.FloatTensor) and self.use_parallel:
            output = nn.parallel.data_parallel(self.model, input, self.gpu_ids)
        else:
            input1 = input
            output0 = self.branch_conv0(input1)  # 初始（4，3，256，256）-->(4,64,256,256)

            output1 = self.branch_conv1(output0)  # (4,64,256,256)--(4,64,256,256)

            residual1 = self.residual_block1(output1)
            fft1 = self.branch_fft1(output1)
            output2 = self.DP(residual1, fft1)
            output2_5 = self.branch_conv2(output2)  # (4,64,256,256)--(4,128,128,128)

            residual2 = self.residual_block2(output2_5)
            fft2 = self.branch_fft2(output2_5)
            output3 = self.DP(residual2, fft2)
            output3_5 = self.branch_conv3(output3)  # (4,128,128,128)--(4,256,64,64)

            residual3 = self.residual_block3(output3_5)
            fft3 = self.branch_fft3(output3_5)
            output4 = self.DP(residual3, fft3)
            output4_5 = self.branch_conv4(output4)  # (4,256,64,64)--(4,512,32,32)

            output5 = self.rd(output4_5)
            output5_5 = output5 + self.sa_h(output5) + self.sa_w(output5)

            output6 = self.up_conv6(output5_5) + residual3  # (4,512,32,32)--(4,256,64,64)
            output7 = self.up_conv7(output6) + residual2  # (4,256,64,64)--(4,128,128,128)
            output8 = self.up_conv8(output7) + residual1  # (4,128,128,128)--(4,64,256,256)

            output9 = self.up_conv9(output8)

        if self.learn_residual:
            output = torch.clamp(input + output9, min=-1, max=1)
        return output


# Defines the Unet generator.
# |num_downs|: number of downsamplings in UNet. For example,
# if |num_downs| == 7, image of size 128x128 will become of size 1x1
# at the bottleneck
class UnetGenerator(nn.Module):
    def __init__(
            self, input_nc, output_nc, num_downs, ngf=64, norm_layer=nn.BatchNorm2d,
            use_dropout=False, gpu_ids=[], use_parallel=True, learn_residual=False):
        super(UnetGenerator, self).__init__()
        self.gpu_ids = gpu_ids
        self.use_parallel = use_parallel
        self.learn_residual = learn_residual
        # currently support only input_nc == output_nc
        assert (input_nc == output_nc)

        # construct unet structure
        unet_block = UnetSkipConnectionBlock(ngf * 8, ngf * 8, norm_layer=norm_layer, innermost=True)
        for i in range(num_downs - 5):
            unet_block = UnetSkipConnectionBlock(ngf * 8, ngf * 8, unet_block, norm_layer=norm_layer,
                                                 use_dropout=use_dropout)
        unet_block = UnetSkipConnectionBlock(ngf * 4, ngf * 8, unet_block, norm_layer=norm_layer)
        unet_block = UnetSkipConnectionBlock(ngf * 2, ngf * 4, unet_block, norm_layer=norm_layer)
        unet_block = UnetSkipConnectionBlock(ngf, ngf * 2, unet_block, norm_layer=norm_layer)
        unet_block = UnetSkipConnectionBlock(output_nc, ngf, unet_block, outermost=True, norm_layer=norm_layer)
        self.model = unet_block

    def forward(self, input):
        if self.gpu_ids and isinstance(input.data, torch.cuda.FloatTensor) and self.use_parallel:
            output = nn.parallel.data_parallel(self.model, input, self.gpu_ids)
        else:
            output = self.model(input)
        if self.learn_residual:
            output = input + output
            output = torch.clamp(output, min=-1, max=1)

        return output



class UnetGenerator1(nn.Module):
    def __init__(
            self, input_nc, ndf=64, norm_layer=nn.BatchNorm2d,
            use_sigmoid=False, gpu_ids=[], use_parallel=True):

        super(UnetGenerator1, self).__init__()
        self.gpu_ids = gpu_ids
        self.use_parallel = use_parallel

        # currently support only input_nc == output_nc

        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d



        model1 = [
            nn.Conv2d(3, 64, kernel_size=4, stride=2, padding=1, bias=use_bias),
            nn.LeakyReLU(0.2, True)
        ]

        model2 = [
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1, bias=use_bias),
            norm_layer(128),
            nn.LeakyReLU(0.2, True)
        ]

        model3 = [
            nn.Conv2d(128, 256, kernel_size=4, stride=2, padding=1, bias=use_bias),
            norm_layer(256),
            nn.LeakyReLU(0.2, True)
        ]


        model4 = [
            nn.Conv2d(256, 512, kernel_size=4, stride=2, padding=1, bias=use_bias),
            norm_layer(512),
            nn.LeakyReLU(0.2, True)
        ]

        model5 = [
            nn.Conv2d(512, 1, kernel_size=4, stride=1, padding=1, bias=use_bias),
            nn.Sigmoid()
        ]

        self.l1 = nn.Sequential(*model1)
        self.l2 = nn.Sequential(*model2)
        self.l3 = nn.Sequential(*model3)
        self.l4 = nn.Sequential(*model4)
        self.l5 = nn.Sequential(*model5)

    def forward(self, input):
        if self.gpu_ids and isinstance(input.data, torch.cuda.FloatTensor) and self.use_parallel:
            output = nn.parallel.data_parallel(self.model, input, self.gpu_ids)
        else:
            input1=input

            output1 = self.l1(input1)
            output2 = self.l2(output1)
            output3 = self.l3(output2)
            output4 = self.l4(output3)
            output5 = self.l5(output4)

        return output1,output2,output3,output4,output5



# Defines the submodule with skip connection.
# X -------------------identity---------------------- X
#   |-- downsampling -- |submodule| -- upsampling --|
class UnetSkipConnectionBlock(nn.Module):
    def __init__(
            self, outer_nc, inner_nc, submodule=None,
            outermost=False, innermost=False, norm_layer=nn.BatchNorm2d, use_dropout=False):
        super(UnetSkipConnectionBlock, self).__init__()
        self.outermost = outermost
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d

        dConv = nn.Conv2d(outer_nc, inner_nc, kernel_size=4, stride=2, padding=1, bias=use_bias)
        dRelu = nn.LeakyReLU(0.2, True)
        dNorm = norm_layer(inner_nc)
        uRelu = nn.ReLU(True)
        uNorm = norm_layer(outer_nc)

        if outermost:
            uConv = nn.ConvTranspose2d(inner_nc * 2, outer_nc, kernel_size=4, stride=2, padding=1)
            dModel = [dConv]
            uModel = [uRelu, uConv, nn.Tanh()]
            model = [
                dModel,
                submodule,
                uModel
            ]
        # model = [
        #   # Down
        #   nn.Conv2d( outer_nc, inner_nc, kernel_size=4, stride=2, padding=1, bias=use_bias),
        #
        #   submodule,
        #   # Up
        #   nn.ReLU(True),
        #   nn.ConvTranspose2d(inner_nc * 2, outer_nc, kernel_size=4, stride=2, padding=1),
        #   nn.Tanh()
        # ]
        elif innermost:
            uConv = nn.ConvTranspose2d(inner_nc, outer_nc, kernel_size=4, stride=2, padding=1, bias=use_bias)
            dModel = [dRelu, dConv]
            uModel = [uRelu, uConv, uNorm]
            model = [
                dModel,
                uModel
            ]
        # model = [
        #   # down
        #   nn.LeakyReLU(0.2, True),
        #   # up
        #   nn.ReLU(True),
        #   nn.ConvTranspose2d(inner_nc, outer_nc, kernel_size=4, stride=2, padding=1, bias=use_bias),
        #   norm_layer(outer_nc)
        # ]
        else:
            uConv = nn.ConvTranspose2d(inner_nc * 2, outer_nc, kernel_size=4, stride=2, padding=1, bias=use_bias)
            dModel = [dRelu, dConv, dNorm]
            uModel = [uRelu, uConv, uNorm]

            model = [
                dModel,
                submodule,
                uModel
            ]
            model += [nn.Dropout(0.5)] if use_dropout else []

        # if use_dropout:
        #   model = down + [submodule] + up + [nn.Dropout(0.5)]
        # else:
        #   model = down + [submodule] + up

        self.model = nn.Sequential(*model)

    def forward(self, x):
        if self.outermost:
            return self.model(x)
        else:
            return torch.cat([self.model(x), x], 1)



# Defines the PatchGAN discriminator with the specified arguments.
class NLayerDiscriminator(nn.Module):
    def __init__(self, input_nc, ndf=64, n_layers=3, norm_layer=nn.BatchNorm2d, use_sigmoid=False, gpu_ids=[],
                 use_parallel=True):
        super(NLayerDiscriminator, self).__init__()
        self.gpu_ids = gpu_ids
        self.use_parallel = use_parallel

        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d

        kw = 4
        padw = int(np.ceil((kw - 1) / 2))
        sequence = [
            nn.Conv2d(input_nc, ndf, kernel_size=kw, stride=2, padding=padw),
            nn.LeakyReLU(0.2, True)
        ]

        nf_mult = 1
        nf_mult_prev = 1
        for n in range(1, n_layers):
            nf_mult_prev = nf_mult
            nf_mult = min(2 ** n, 8)
            sequence += [
                nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult,
                          kernel_size=kw, stride=2, padding=padw, bias=use_bias),
                norm_layer(ndf * nf_mult),
                nn.LeakyReLU(0.2, True)
            ]

        nf_mult_prev = nf_mult
        nf_mult = min(2 ** n_layers, 8)
        sequence += [
            nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult, kernel_size=kw, stride=1, padding=padw, bias=use_bias),
            norm_layer(ndf * nf_mult),
            nn.LeakyReLU(0.2, True)
        ]

        sequence += [nn.Conv2d(ndf * nf_mult, 1, kernel_size=kw, stride=1, padding=padw)]

        if use_sigmoid:
            sequence += [nn.Sigmoid()]

        self.model= nn.Sequential(*sequence)

    def forward(self, input):
        if len(self.gpu_ids) and isinstance(input.data, torch.cuda.FloatTensor) and self.use_parallel:
            return nn.parallel.data_parallel(self.model, input, self.gpu_ids)
        else:
            return self.model(input)