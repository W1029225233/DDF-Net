from torch.autograd import Variable
from collections import OrderedDict
import util.util as util
from .base_model import BaseModel
from . import networks
import torch
import os

class TestModel(BaseModel):
    def name(self):
        return 'TestModel'

    def initialize(self, opt):
        assert(not opt.isTrain)
        BaseModel.initialize(self, opt)
        self.input_A = self.Tensor(opt.batchSize, opt.input_nc, opt.fineSize, opt.fineSize)

        self.netG = networks.define_G(opt.input_nc, opt.output_nc, opt.ngf,
                                      opt.which_model_netG, opt.norm, not opt.no_dropout, self.gpu_ids, False,
                                      opt.learn_residual)
        which_epoch = opt.which_epoch
        self.load_network(self.netG, 'G', which_epoch)

        #self.cache_spa = None
        #self.cache_freq = None

        print('---------- Networks initialized -------------')
        networks.print_network(self.netG)
        print('-----------------------------------------------')


    def set_input(self, input):
        # we need to use single_dataset mode
        input_A = input['A']
        temp = self.input_A.clone()
        temp.resize_(input_A.size()).copy_(input_A)
        self.input_A = temp
        self.image_paths = input['A_paths']


    def test(self):
        with torch.no_grad():
            self.real_A = Variable(self.input_A)
            self.fake_B = self.netG(self.real_A)
            # 抓到 TestModel 自身属性
            # self.cache_spa = self.netG.cache_spa
            # self.cache_freq = self.netG.cache_freq
            # 直接存 buffer（已 detach）
            save_dir = os.path.join(self.save_dir, 'features')
            os.makedirs(save_dir, exist_ok=True)
            img_name = os.path.basename(self.image_paths[0]).split('.')[0]

        # 一次全导出
        #torch.save(self.netG.residual1.cpu(), os.path.join(save_dir, f'residual1_{img_name}.pt'))
        #torch.save(self.netG.residual2.cpu(), os.path.join(save_dir, f'residual2_{img_name}.pt'))
        #torch.save(self.netG.residual3.cpu(), os.path.join(save_dir, f'residual3_{img_name}.pt'))
        #torch.save(self.netG.fft1.cpu(),      os.path.join(save_dir, f'fft1_{img_name}.pt'))
        #torch.save(self.netG.fft2.cpu(),      os.path.join(save_dir, f'fft2_{img_name}.pt'))
        #torch.save(self.netG.fft3.cpu(),      os.path.join(save_dir, f'fft3_{img_name}.pt'))
    # get image paths
    def get_image_paths(self):
        return self.image_paths

    def get_current_visuals(self):
        real_A = util.tensor2im(self.real_A.data)
        fake_B = util.tensor2im(self.fake_B.data)
        return OrderedDict([('real_A', real_A), ('fake_B', fake_B)])

    def register_buffer(self, param, param1):
        pass
