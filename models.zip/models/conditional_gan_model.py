from collections import OrderedDict
import util.util as util
from .base_model import BaseModel
from . import networks
from net_canny import Net
import torch.nn.functional as F
from math import exp
import torch
import torch.nn as nn
import torch.autograd as autograd
import torchvision.models as models
from util.image_pool import ImagePool
from torch.autograd import Variable

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class ContentLoss():
	def initialize(self, loss):
		self.criterion = loss
			
	def get_loss(self, fakeIm, realIm):
		return self.criterion(fakeIm, realIm)

class PerceptualLoss():
	def contentFunc(self):
		conv_3_3_layer = 14
		cnn = models.vgg19(pretrained=True).features
		cnn = cnn.cuda()
		model = nn.Sequential()
		model = model.cuda()
		for i,layer in enumerate(list(cnn)):
			model.add_module(str(i),layer)
			if i == conv_3_3_layer:
				break
		return model
		
	def initialize(self, loss):
		self.criterion = loss
		self.contentFunc = self.contentFunc()
			
	def get_loss(self, fakeIm, realIm):
		f_fake = self.contentFunc.forward(fakeIm)
		f_real = self.contentFunc.forward(realIm)
		f_real_no_grad = f_real.detach()
		loss = self.criterion(f_fake, f_real_no_grad)
		return loss


class EdgeLoss():
	def edgeFunc(self,x_real, x_fake):
		net = Net(threshold=3.0,  use_cuda=True)
		net = net.cuda()
		net.eval()
		batch_size = x_real.size()[0]
		g_loss_edge=0.0
		for i in range(batch_size):
			x= x_real[i,:,:,:].unsqueeze(0)
			img_x_real = Variable(x).cuda()
			thresholded_x_real = net(img_x_real)
			thresholded_real = torch.cuda.FloatTensor(thresholded_x_real)

			y= x_fake[i,:,:,:].unsqueeze(0)
			img_x_fake = Variable(y).cuda()
			thresholded_x_fake = net(img_x_fake)
			thresholded_fake = torch.cuda.FloatTensor(thresholded_x_fake)
			g_loss_edge = torch.mean(torch.abs(thresholded_real-thresholded_fake))
		return g_loss_edge

def edge_init_loss():
	edge_loss = None
	edge_loss = EdgeLoss()
	return edge_loss

class Color():
	def blur(self, restore, sharp):
		window_size=1
		sigma=0.5
		gauss = torch.Tensor([exp(-(miu - window_size//2)**2/float(2*sigma**2)) for miu in range(window_size)])
		kernel = gauss/gauss.sum()
		_1D_window =kernel.unsqueeze(1)
		_2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
		window = _2D_window.expand(1, 3, window_size, window_size).contiguous()
		window = window.cuda()
		h_x =restore.size()[2]
		h_y =sharp.size()[2]
		w_x =restore.size()[3]
		w_y = sharp.size()[3]  # 获取sharp的宽度

		h_x_tv =restore[:,:,1:,:]-restore[:,:,:h_x-1,:]
		w_x_tv =restore[:,:,:,1:]-restore[:,:,:,:w_x-1]

		h_y_tv =sharp[:,:,1:,:]-sharp[:,:,:h_y-1,:]
		w_y_tv =sharp[:,:,:,1:]-sharp[:,:,:,:w_y-1]

		x1_x = F.conv2d(h_x_tv, window, padding=1).cuda()
		y1_x = F.conv2d(h_y_tv, window, padding=1).cuda()
		x1_y = F.conv2d(w_x_tv, window, padding=1).cuda()
		y1_y = F.conv2d(w_y_tv, window, padding=1).cuda()
		color_loss = torch.mean(torch.pow(x1_x - y1_x, 2)) + torch.mean(torch.pow(x1_y - y1_y, 2))
		return color_loss

class FFTLoss(nn.Module):
	def __init__(self):
		super(FFTLoss, self).__init__()
		self.L1_loss = nn.L1Loss()

	def forward(self, pred, target):
		pred_fft = torch.fft.fft2(pred, dim=(-2, -1), norm="ortho")  # 使用 "ortho" 归一化
		pred_fft = torch.stack([pred_fft.real, pred_fft.imag], dim=-1)
		target_fft = torch.fft.fft2(target, dim=(-2, -1), norm="ortho")  # 使用 "ortho" 归一化
		target_fft = torch.stack([target_fft.real, target_fft.imag], dim=-1)
		l1_loss = self.L1_loss(pred_fft, target_fft)
		return l1_loss


class GANLoss(nn.Module):
	def __init__(self, use_l1=True, target_real_label=1.0, target_fake_label=0.0,
				 tensor=torch.FloatTensor):
		super(GANLoss, self).__init__()
		self.real_label = target_real_label
		self.fake_label = target_fake_label
		self.real_label_var = None
		self.fake_label_var = None
		self.Tensor = tensor
		if use_l1:
			self.loss = nn.L1Loss()
		else:
			self.loss = nn.BCELoss()

	def get_target_tensor(self, input, target_is_real):
		target_tensor = None
		if target_is_real:
			create_label = ((self.real_label_var is None) or
							(self.real_label_var.numel() != input.numel()))
			if create_label:
				real_tensor = self.Tensor(input.size()).fill_(self.real_label)
				self.real_label_var = Variable(real_tensor, requires_grad=False)
			target_tensor = self.real_label_var
		else:
			create_label = ((self.fake_label_var is None) or
							(self.fake_label_var.numel() != input.numel()))
			if create_label:
				fake_tensor = self.Tensor(input.size()).fill_(self.fake_label)
				self.fake_label_var = Variable(fake_tensor, requires_grad=False)
			target_tensor = self.fake_label_var
		return target_tensor

	def __call__(self, input, target_is_real):
		target_tensor = self.get_target_tensor(input, target_is_real)
		return self.loss(input, target_tensor)


class DiscLoss():
	def name(self):
		return 'DiscLoss'

	def initialize(self, opt, tensor):
		self.criterionGAN = GANLoss(use_l1=False, tensor=tensor)
		self.fake_AB_pool = ImagePool(opt.pool_size)

	def get_g_loss(self, net, realA, fakeB):
		# First, G(A) should fake the discriminator
		pred_fake = net.forward(fakeB)
		return self.criterionGAN(pred_fake, 1)

	def get_loss(self, net, realA, fakeB, realB):
		# Fake
		# stop backprop to the generator by detaching fake_B
		# Generated Image Disc Output should be close to zero
		self.pred_fake = net.forward(fakeB.detach())
		self.loss_D_fake = self.criterionGAN(self.pred_fake, 0)

		# Real
		self.pred_real = net.forward(realB)
		self.loss_D_real = self.criterionGAN(self.pred_real, 1)

		# Combined loss
		self.loss_D = (self.loss_D_fake + self.loss_D_real) * 0.5
		return self.loss_D


class DiscLossLS(DiscLoss):

	def name(self):
		return 'DiscLossLS'

	def initialize(self, opt, tensor):
		DiscLoss.initialize(self, opt, tensor)
		self.criterionGAN = GANLoss(use_l1=True, tensor=tensor)

	def get_g_loss(self, net, realA, fakeB):
		return DiscLoss.get_g_loss(self, net, realA, fakeB)

	def get_loss(self, net, realA, fakeB, realB):
		return DiscLoss.get_loss(self, net, realA, fakeB, realB)


class DiscLossWGANGP(DiscLossLS):
	def name(self):
		return 'DiscLossWGAN-GP'

	def initialize(self, opt, tensor):
		DiscLossLS.initialize(self, opt, tensor)
		self.LAMBDA = 10

	def get_g_loss(self, net, realA, fakeB):
		# First, G(A) should fake the discriminator
		self.D_fake = net.forward(fakeB)
		return -self.D_fake.mean()

	def calc_gradient_penalty(self, netD, real_data, fake_data):
		alpha = torch.rand(1, 1)
		alpha = alpha.expand(real_data.size())
		alpha = alpha.cuda()

		interpolates = alpha * real_data + ((1 - alpha) * fake_data)

		interpolates = interpolates.cuda()
		interpolates = Variable(interpolates, requires_grad=True)

		disc_interpolates = netD.forward(interpolates)

		gradients = autograd.grad(outputs=disc_interpolates, inputs=interpolates,
								  grad_outputs=torch.ones(disc_interpolates.size()).cuda(),
								  create_graph=True, retain_graph=True, only_inputs=True)[0]

		gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean() * self.LAMBDA
		return gradient_penalty

	def get_loss(self, net, realA, fakeB, realB):
		self.D_fake = net.forward(fakeB.detach())
		self.D_fake = self.D_fake.mean()

		# Real
		self.D_real = net.forward(realB)
		self.D_real = self.D_real.mean()
		# Combined loss
		self.loss_D = self.D_fake - self.D_real
		gradient_penalty = self.calc_gradient_penalty(net, realB.data, fakeB.data)
		return self.loss_D + gradient_penalty


def init_loss(opt, tensor):
	disc_loss = None
	content_loss = None

	if opt.model == 'content_gan':  # 这个
		content_loss = PerceptualLoss()
		content_loss.initialize(nn.MSELoss())
	elif opt.model == 'pix2pix':
		content_loss = ContentLoss()
		content_loss.initialize(nn.L1Loss())
	else:
		raise ValueError("Model [%s] not recognized." % opt.model)

	if opt.gan_type == 'wgan-gp':  # 这个
		disc_loss = DiscLossWGANGP()
	elif opt.gan_type == 'lsgan':
		disc_loss = DiscLossLS()
	elif opt.gan_type == 'gan':
		disc_loss = DiscLoss()
	else:
		raise ValueError("GAN [%s] not recognized." % opt.gan_type)
	disc_loss.initialize(opt, tensor)
	return disc_loss, content_loss

class ConditionalGAN(BaseModel):
	def name(self):
		return 'ConditionalGANModel'

	def initialize(self, opt):
		BaseModel.initialize(self, opt)

		self.isTrain = opt.isTrain
		# define tensors
		self.input_A = self.Tensor(opt.batchSize, opt.input_nc,
								   opt.fineSize, opt.fineSize)
		self.input_B = self.Tensor(opt.batchSize, opt.output_nc,
								   opt.fineSize, opt.fineSize)

		self.real = torch.ones(opt.batchSize, 1, opt.TargetSize, opt.TargetSize).to(device)
		self.fake = torch.zeros(opt.batchSize, 1, opt.TargetSize, opt.TargetSize).to(device)

		# load/define networks
		#Temp Fix for nn.parallel as nn.parallel crashes oc calculating gradient penalty
		use_parallel = not opt.gan_type == 'wgan-gp'
		self.netGs = networks.define_G(3,3,3,'resnet_6blocks', opt.norm, not opt.no_dropout, self.gpu_ids, use_parallel, opt.learn_residual)
		self.netG = networks.define_G(opt.input_nc, opt.output_nc, opt.ngf, opt.which_model_netG, opt.norm, not opt.no_dropout,  self.gpu_ids, use_parallel, opt.learn_residual)

		if self.isTrain:
			use_sigmoid = opt.gan_type == 'gan'
			self.netD = networks.define_D(opt.output_nc, opt.ndf,
										  opt.which_model_netD,
										  opt.n_layers_D, opt.norm, use_sigmoid, self.gpu_ids, use_parallel)
		# 加载生成器和判别器的网络
		self.netGs = networks.define_G(3, 3, 3, 'resnet_6blocks', opt.norm, not opt.no_dropout, self.gpu_ids,
									   use_parallel, opt.learn_residual)
		self.netG = networks.define_G(opt.input_nc, opt.output_nc, opt.ngf, opt.which_model_netG, opt.norm,
									  not opt.no_dropout, self.gpu_ids, use_parallel, opt.learn_residual)

		if self.isTrain:
			use_sigmoid = opt.gan_type == 'gan'
			self.netD = networks.define_D(opt.output_nc, opt.ndf, opt.which_model_netD, opt.n_layers_D, opt.norm,
										  use_sigmoid, self.gpu_ids, use_parallel)

		# 如果需要继续训练，则加载检查点
		if opt.continue_train:
			self.load_network(self.netG, 'G', opt.which_epoch)
			self.load_network(self.netD, 'D', opt.which_epoch)


		if self.isTrain:
			self.fake_AB_pool = ImagePool(opt.pool_size)
			self.old_lr = opt.lr

			self.optimizer_G = torch.optim.Adam(self.netG.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
			self.optimizer_D = torch.optim.Adam(self.netD.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))

			#self.optimizer_G = torch.optim.AdamW(self.netG.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999), weight_decay=1e-5)
			#self.optimizer_D = torch.optim.AdamW(self.netD.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999), weight_decay=1e-5)


			self.criticUpdates = 5 if opt.gan_type == 'wgan-gp' else 1
			
			# define loss functions

			self.discLoss, self.contentLoss = init_loss(opt, self.Tensor)
			self.edgeLoss = edge_init_loss()
			self.L1_loss =nn.L1Loss()
			self.L2_loss =nn.MSELoss()
			self.vgg = PerceptualLoss()
			self.vgg.initialize(loss=nn.MSELoss())
			self.fft_loss = FFTLoss()
			self.color_loss = Color()

		print('---------- Networks initialized -------------')
		networks.print_network(self.netG)
		if self.isTrain:
			networks.print_network(self.netD)
		print('-----------------------------------------------')

	def set_input(self, input):
		AtoB = self.opt.which_direction == 'AtoB'
		input_A = input['A' if AtoB else 'B']
		input_B = input['B' if AtoB else 'A']
		self.input_A.resize_(input_A.size()).copy_(input_A)
		self.input_B.resize_(input_B.size()).copy_(input_B)
		self.image_paths = input['A_paths' if AtoB else 'B_paths']

	def forward(self):
		self.real_A = Variable(self.input_A)
		self.vgg_B = self.netGs.forward(self.real_A)  #先得到经过vgg19的预训练张量
		self.real_B = Variable(self.input_B)
		self.fake_B = self.netG.forward(self.vgg_B)	  #经过预训练后的再经过自己的模型

	# no backprop gradients
	torch.cuda.empty_cache()
	def test(self):
		with torch.no_grad():
			self.real_A =torch.autograd.Variable(self.input_A)
			self.fake_B = self.netG.forward(self.real_A)
			self.real_B = torch.autograd.Variable(self.input_B)

	# get image paths
	def get_image_paths(self):
		return self.image_paths

	def backward_D(self):
		self.loss_D = self.discLoss.get_loss(self.netD, self.real_A, self.fake_B, self.real_B)
		self.loss_D.backward(retain_graph=True)

	def backward_G(self):
		self.loss_G_GAN = self.discLoss.get_g_loss(self.netD, self.real_A, self.fake_B)
		self.loss_G_Content = self.contentLoss.get_loss(self.fake_B, self.real_B) *10
		# self.loss_Color = self.color_loss.blur(self.fake_B, self.real_B) *10
		# self.loss_G_rec  = self.L1_loss(self.real_B, self.real_B1) *100
		self.loss_fft = self.fft_loss(self.fake_B, self.real_B) * 12
		self.loss_G_vgg =  self.L2_loss(self.vgg_B,  self.real_B)*10
		self.loss_G_edge = self.edgeLoss.edgeFunc(self.fake_B, self.real_B) *12
		self.loss_G = self.loss_G_GAN + self.loss_G_Content + self.loss_G_vgg + self.loss_G_edge + self.loss_fft
		self.loss_G.backward()

	def optimize_parameters(self):
		self.forward()
		# 更新生成器（Generator）的参数之前，先更新判别器（Discriminator）的参数5次
		for iter_d in range(self.criticUpdates):
			self.optimizer_D.zero_grad()
			self.backward_D()
			self.optimizer_D.step()

		self.optimizer_G.zero_grad()
		self.backward_G()
		self.optimizer_G.step()

	def get_current_errors(self):
		return OrderedDict([('G_GAN', self.loss_G_GAN.item()),
							('G_Content', self.loss_G_Content.item()),
							('D', self.loss_D.item()),
							('G_vgg', self.loss_G_vgg.item()),
							('G', self.loss_G.item()),
							('G_edge', self.loss_G_edge.item()),
							('loss_fft', self.loss_fft.item()),
							])

	def get_current_visuals(self):
		real_A = util.tensor2im(self.real_A.data)
		fake_B = util.tensor2im(self.fake_B.data)
		real_B = util.tensor2im(self.real_B.data)

		return OrderedDict([('real_A', real_A), ('fake_B', fake_B), ('real_B', real_B)])

	def save(self, label):
		self.save_network(self.netG, 'G', label, self.gpu_ids)
		self.save_network(self.netD, 'D', label, self.gpu_ids)

	def update_learning_rate(self):
		lrd = self.opt.lr / self.opt.niter_decay
		lr = self.old_lr - lrd
		for param_group in self.optimizer_D.param_groups:
			param_group['lr'] = lr
		for param_group in self.optimizer_G.param_groups:
			param_group['lr'] = lr
		print('update learning rate: %f -> %f' % (self.old_lr, lr))
		self.old_lr = lr
